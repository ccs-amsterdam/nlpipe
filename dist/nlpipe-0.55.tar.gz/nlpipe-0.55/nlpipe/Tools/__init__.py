from . import test_upper  # forces the tools to register themselves
