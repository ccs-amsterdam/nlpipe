from . import test_upper, alpino, alpinonaf, coreNLP, frog, newsreader, parzu  # forces the tools to register themselves
