from . import test_upper, alpino, alpinonaf, coreNLP, frog, newsreader, parzu, udpipe, gensim  # forces the tools to register themselves
