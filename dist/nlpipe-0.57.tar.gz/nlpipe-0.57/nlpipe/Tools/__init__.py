from . import test_upper, alpino, alpinonaf, coreNLP, frog, newsreader, parzu, udpipe, gensim, spacy, portulan  # forces the tools to register themselves
